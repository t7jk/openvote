<?php
defined( 'ABSPATH' ) || exit;

class Evoting_Deactivator {

    public static function deactivate(): void {
        // Stub – nothing to do on deactivation.
    }
}
