/**
 * E-Voting Public JS – voting form, countdown, results loading
 */
(function () {
    'use strict';

    var cfg = window.evotingPublic || {};

    document.addEventListener('DOMContentLoaded', function () {
        initCountdowns();
        initVotingForms();
        initResults();
    });

    /* ── Countdown Timer ── */

    function initCountdowns() {
        var countdowns = document.querySelectorAll('.evoting-countdown');
        if (!countdowns.length) return;

        function update() {
            countdowns.forEach(function (el) {
                var end  = new Date(el.dataset.end).getTime();
                var diff = end - Date.now();

                if (diff <= 0) {
                    el.textContent = cfg.i18n.ended;
                    return;
                }

                var d = Math.floor(diff / 86400000);
                var h = Math.floor((diff % 86400000) / 3600000);
                var m = Math.floor((diff % 3600000) / 60000);
                var s = Math.floor((diff % 60000) / 1000);

                var parts = [];
                if (d > 0) parts.push(d + ' ' + cfg.i18n.days);
                parts.push(h + ' ' + cfg.i18n.hours);
                parts.push(m + ' ' + cfg.i18n.minutes);
                parts.push(s + ' ' + cfg.i18n.seconds);

                el.textContent = parts.join(' ');
            });
        }

        update();
        setInterval(update, 1000);
    }

    /* ── Voting Forms ── */

    function initVotingForms() {
        document.querySelectorAll('.evoting-poll__form').forEach(function (form) {
            form.addEventListener('submit', function (e) {
                e.preventDefault();

                var pollId    = form.dataset.pollId;
                var msgEl     = form.querySelector('.evoting-poll__message');
                var submitBtn = form.querySelector('.evoting-poll__submit');

                // Collect answers: question_id (int) → answer_id (int).
                var answers     = {};
                var allAnswered = true;

                form.querySelectorAll('.evoting-poll__question').forEach(function (fs) {
                    var checked = fs.querySelector('input[type="radio"]:checked');
                    if (!checked) { allAnswered = false; return; }
                    var qId = parseInt(checked.name.replace('question_', ''), 10);
                    answers[qId] = parseInt(checked.value, 10);
                });

                if (!allAnswered) {
                    showMessage(msgEl, cfg.i18n.answerAll, 'error');
                    return;
                }

                submitBtn.disabled = true;

                var block = form.closest('.evoting-poll-block');
                var nonce = block ? block.dataset.nonce : cfg.nonce;

                fetch(cfg.restUrl + '/polls/' + pollId + '/vote', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
                    body: JSON.stringify({ answers: answers })
                })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    if (data.success) {
                        showMessage(msgEl, cfg.i18n.voteSuccess, 'success');
                        form.querySelectorAll('input, button').forEach(function (el) { el.disabled = true; });
                    } else {
                        showMessage(msgEl, data.message || cfg.i18n.voteError, 'error');
                        submitBtn.disabled = false;
                    }
                })
                .catch(function () {
                    showMessage(msgEl, cfg.i18n.voteError, 'error');
                    submitBtn.disabled = false;
                });
            });
        });
    }

    function showMessage(el, text, type) {
        if (!el) return;
        el.textContent = text;
        el.className = 'evoting-poll__message evoting-poll__message--' + type;
    }

    /* ── Results (ended polls) ── */

    function initResults() {
        document.querySelectorAll('.evoting-poll__results').forEach(function (container) {
            var pollId = container.dataset.pollId;
            if (!pollId) return;

            var block = container.closest('.evoting-poll-block');
            var nonce = block ? block.dataset.nonce : cfg.nonce;

            fetch(cfg.restUrl + '/polls/' + pollId + '/results', {
                headers: { 'X-WP-Nonce': nonce }
            })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.code) {
                    container.innerHTML = '<p>' + escapeHtml(data.message || '') + '</p>';
                    return;
                }
                renderResults(container, data);
            })
            .catch(function () {
                container.innerHTML = '<p>' + escapeHtml(cfg.i18n.voteError) + '</p>';
            });
        });
    }

    function renderResults(container, data) {
        var eligible   = data.total_eligible || 0;
        var voted      = data.total_voters   || 0;
        var absent     = data.non_voters     || 0;
        var pctVoted   = eligible > 0 ? (voted  / eligible * 100).toFixed(1) : '0.0';
        var pctAbsent  = eligible > 0 ? (absent / eligible * 100).toFixed(1) : '0.0';

        var html = '<div class="evoting-results">';

        /* Participation summary */
        html += '<div class="evoting-results__participation">';
        html += '<h4>' + escapeHtml(cfg.i18n.participation) + '</h4>';
        html += participationRow(cfg.i18n.totalEligible, eligible, '100.0', 'eligible');
        html += participationRow(cfg.i18n.totalVoters,   voted,    pctVoted,  'voted');
        html += participationRow(cfg.i18n.totalAbsent,   absent,   pctAbsent, 'absent');
        html += '</div>';

        /* Per-question answer bars */
        data.questions.forEach(function (q, qi) {
            html += '<div class="evoting-results__question">';
            html += '<h4>' + (qi + 1) + '. ' + escapeHtml(q.question_text) + '</h4>';

            q.answers.forEach(function (answer, ai) {
                var barClass = answer.is_abstain
                    ? 'evoting-results__bar--wstrzymuje_sie'
                    : (ai === 0 ? 'evoting-results__bar--za' : 'evoting-results__bar--przeciw');

                var pct   = parseFloat(answer.pct) || 0;
                var label = escapeHtml(answer.text);
                if (answer.is_abstain) {
                    label += ' <em>(' + escapeHtml(cfg.i18n.inclAbsent) + ')</em>';
                }

                html += '<div class="evoting-results__bar-container">';
                html += '<div class="evoting-results__bar-label">';
                html += '<span>' + label + '</span>';
                html += '<span>' + answer.count + ' (' + pct.toFixed(1) + '%)</span>';
                html += '</div>';
                html += '<div class="evoting-results__bar ' + barClass + '" style="width:' + pct.toFixed(1) + '%"></div>';
                html += '</div>';
            });

            html += '</div>';
        });

        /* Voter list – anonymized nicenames, toggled */
        if (data.voters && data.voters.length) {
            html += '<div class="evoting-results__voters-section">';
            html += '<button type="button" class="evoting-voters-toggle">' + escapeHtml(cfg.i18n.showVoters) + '</button>';
            html += '<div class="evoting-results__voters" style="display:none">';
            html += '<h4>' + escapeHtml(cfg.i18n.voterList) + '</h4><ul>';
            data.voters.forEach(function (v) {
                html += '<li>' + escapeHtml(v.nicename) + '</li>';
            });
            html += '</ul></div></div>';
        }

        html += '</div>';
        container.innerHTML = html;

        /* Wire up voter-list toggle */
        var toggleBtn = container.querySelector('.evoting-voters-toggle');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', function () {
                var list = container.querySelector('.evoting-results__voters');
                var open = list.style.display !== 'none';
                list.style.display = open ? 'none' : '';
                toggleBtn.textContent = open ? cfg.i18n.showVoters : cfg.i18n.hideVoters;
            });
        }
    }

    function participationRow(label, count, pct, cssKey) {
        return '<div class="evoting-results__bar-container">'
            + '<div class="evoting-results__bar-label">'
            + '<span>' + escapeHtml(label) + '</span>'
            + '<span>' + count + ' (' + pct + '%)</span>'
            + '</div>'
            + '<div class="evoting-results__bar evoting-results__bar--' + cssKey + '" style="width:' + pct + '%"></div>'
            + '</div>';
    }

    function escapeHtml(str) {
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(String(str)));
        return div.innerHTML;
    }
})();
